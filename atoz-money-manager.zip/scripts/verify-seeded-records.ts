import { eq } from "drizzle-orm";
import { customers, monthlyBills, wapdaRecords } from "../drizzle/schema";
import { getDb } from "../server/db";
const db = await getDb();
if (!db) throw new Error("Database unavailable");
const customerRows = await db.select().from(customers).where(eq(customers.serialNumber, 1));
const bills = customerRows[0] ? await db.select().from(monthlyBills).where(eq(monthlyBills.customerId, customerRows[0].id)) : [];
const wapda = await db.select().from(wapdaRecords);
console.log(JSON.stringify({
  customer: customerRows.map(c => ({ id: c.id, name: c.name, serialNumber: c.serialNumber, meterNumber: c.meterNumber, photoUrl: c.photoUrl })),
  bills: bills.map(b => ({ invoiceNumber: b.invoiceNumber, month: b.month, year: b.year, totalPayable: b.totalPayable, receivedAmount: b.receivedAmount, status: b.status })),
  wapda: wapda.map(w => ({ month: w.month, year: w.year, totalBill: w.totalBill })),
}, null, 2));
process.exit(0);
