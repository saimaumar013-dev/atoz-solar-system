import { asc, count, max, min } from "drizzle-orm";
import { customers } from "../drizzle/schema";
import { getDb } from "../server/db";

const db = await getDb();
if (!db) throw new Error("Database unavailable");
const rows = await db.select({ id: customers.id, sNo: customers.sNo, serialNumber: customers.serialNumber, name: customers.name }).from(customers).orderBy(asc(customers.sNo));
const [summary] = await db.select({ total: count(customers.id), minSNo: min(customers.sNo), maxSNo: max(customers.sNo) }).from(customers);
const unique = new Set(rows.map(row => row.sNo));
const expected = Array.from({ length: rows.length }, (_, index) => index + 1);
const sequential = rows.every((row, index) => row.sNo === expected[index]);
console.log(JSON.stringify({ total: Number(summary?.total ?? 0), unique: unique.size, minSNo: Number(summary?.minSNo ?? 0), maxSNo: Number(summary?.maxSNo ?? 0), sequential, first: rows.slice(0, 5), last: rows.slice(-5) }, null, 2));
