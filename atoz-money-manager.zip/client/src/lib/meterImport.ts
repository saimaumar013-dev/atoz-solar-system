export function parseBillingPeriod(value: unknown, fallbackMonth: number, fallbackYear: number) {
  if (typeof value !== "string") return { month: fallbackMonth, year: fallbackYear };
  const match = value.match(/(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})/i);
  if (!match) return { month: fallbackMonth, year: fallbackYear };
  const monthNames = ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december"];
  return { month: monthNames.indexOf(match[1].toLowerCase()) + 1, year: Number(match[2]) };
}

export function normalizeCustomerReadingExport(input: unknown, fallbackMonth = new Date().getMonth() + 1, fallbackYear = new Date().getFullYear()) {
  const root = input && typeof input === "object" && !Array.isArray(input) ? input as Record<string, unknown> : null;
  const rows = Array.isArray(root?.customers) ? root.customers : Array.isArray(input) ? input : null;
  if (!rows) return null;
  const entries = rows.map((raw, index) => {
    const row = raw && typeof raw === "object" ? raw as Record<string, unknown> : {};
    const idMatch = typeof row.customerId === "string" ? row.customerId.match(/(\d+)$/) : null;
    const sNo = row.sNo ?? (idMatch ? Number(idMatch[1]) : undefined);
    return {
      sNo,
      nameTag: row.nameTag ?? row.name,
      previousReading: row.previousReading ?? 0,
      currentReading: row.currentReading,
      ratePerUnit: row.ratePerUnit ?? root?.defaultRatePerUnit ?? 65,
      _index: index,
    };
  });
  if (!entries.some(row => row.currentReading !== undefined)) return null;
  return { entries, period: parseBillingPeriod(root?.billingPeriod, fallbackMonth, fallbackYear), readingDate: typeof root?.date === "string" ? root.date : undefined };
}
