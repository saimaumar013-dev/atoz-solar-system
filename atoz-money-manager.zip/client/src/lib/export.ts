export function downloadCsv(filename: string, rows: Record<string, unknown>[]) {
  if (!rows.length) return;
  const headers = Object.keys(rows[0]);
  const escape = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  const csv = [headers.map(escape).join(","), ...rows.map(row => headers.map(h => escape(row[h])).join(","))].join("\n");
  const blob = new Blob(["\ufeff", csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob); const anchor = document.createElement("a"); anchor.href = url; anchor.download = filename; anchor.click(); URL.revokeObjectURL(url);
}

export async function generateElementPdf(element: HTMLElement, filename: string) {
  const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
  const canvas = await html2canvas(element, { scale: 2, useCORS: true, backgroundColor: "#fffdf8", logging: false });
  const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: "legal", compress: true });
  const pageW = pdf.internal.pageSize.getWidth(); const pageH = pdf.internal.pageSize.getHeight(); const margin = 8;
  const scale = Math.min((pageW - margin * 2) / canvas.width, (pageH - margin * 2) / canvas.height);
  const width = canvas.width * scale; const height = canvas.height * scale;
  pdf.addImage(canvas.toDataURL("image/jpeg", .92), "JPEG", (pageW - width) / 2, (pageH - height) / 2, width, height, undefined, "FAST");
  pdf.save(filename);
}

export async function generateMultiPagePdf(elements: HTMLElement[], filename: string) {
  const [{ default: html2canvas }, { jsPDF }] = await Promise.all([import("html2canvas"), import("jspdf")]);
  const pdf = new jsPDF({ orientation: "landscape", unit: "mm", format: "legal", compress: true });
  for (let i = 0; i < elements.length; i++) {
    if (i) pdf.addPage("legal", "landscape");
    const canvas = await html2canvas(elements[i], { scale: 1.5, useCORS: true, backgroundColor: "#fffdf8", logging: false });
    const pageW = pdf.internal.pageSize.getWidth(), pageH = pdf.internal.pageSize.getHeight(), margin = 8;
    const scale = Math.min((pageW - margin * 2) / canvas.width, (pageH - margin * 2) / canvas.height);
    const width = canvas.width * scale, height = canvas.height * scale;
    pdf.addImage(canvas.toDataURL("image/jpeg", .9), "JPEG", (pageW - width) / 2, (pageH - height) / 2, width, height, undefined, "FAST");
  }
  pdf.save(filename);
}

export function shareWhatsApp(phone: string | null | undefined, message: string) {
  const digits = (phone || "").replace(/\D/g, "");
  window.open(`https://wa.me/${digits}?text=${encodeURIComponent(message)}`, "_blank", "noopener,noreferrer");
}

export function shareEmail(to: string | null | undefined, subject: string, body: string) {
  window.location.href = `mailto:${encodeURIComponent(to || "")}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}
