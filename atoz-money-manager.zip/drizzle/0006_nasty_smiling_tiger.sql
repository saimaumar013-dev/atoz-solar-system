CREATE TABLE `customer_daily_wapda_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`customerName` varchar(200) NOT NULL,
	`sNo` int NOT NULL,
	`month` int NOT NULL,
	`year` int NOT NULL,
	`readingDate` varchar(10) NOT NULL,
	`previousReading` double NOT NULL DEFAULT 0,
	`currentReading` double NOT NULL DEFAULT 0,
	`unitsConsumed` double NOT NULL DEFAULT 0,
	`ratePerUnit` double NOT NULL DEFAULT 65,
	`totalAmount` double NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customer_daily_wapda_records_id` PRIMARY KEY(`id`),
	CONSTRAINT `customer_daily_wapda_unique` UNIQUE(`customerId`,`year`,`month`,`readingDate`)
);
--> statement-breakpoint
ALTER TABLE `customer_daily_wapda_records` ADD CONSTRAINT `customer_daily_wapda_records_customerId_customers_id_fk` FOREIGN KEY (`customerId`) REFERENCES `customers`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `customer_daily_wapda_period_idx` ON `customer_daily_wapda_records` (`year`,`month`);--> statement-breakpoint
CREATE INDEX `customer_daily_wapda_customer_idx` ON `customer_daily_wapda_records` (`customerId`);