import {
  boolean,
  double,
  index,
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const userPermissions = mysqlTable("user_permissions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }).unique(),
  canViewCustomers: boolean("canViewCustomers").default(true).notNull(),
  canManageCustomers: boolean("canManageCustomers").default(false).notNull(),
  canViewBills: boolean("canViewBills").default(true).notNull(),
  canManageBills: boolean("canManageBills").default(false).notNull(),
  canViewReports: boolean("canViewReports").default(true).notNull(),
  canManageWapda: boolean("canManageWapda").default(false).notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export const customers = mysqlTable("customers", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  sNo: int("sNo").notNull(),
  serialNumber: int("serialNumber").notNull(),
  photoUrl: text("photoUrl"),
  email: varchar("email", { length: 320 }),
  mobileNumber: varchar("mobileNumber", { length: 40 }),
  whatsappNumber: varchar("whatsappNumber", { length: 40 }),
  cnic: varchar("cnic", { length: 40 }),
  address: text("address"),
  connectionDate: varchar("connectionDate", { length: 10 }),
  installationDate: varchar("installationDate", { length: 10 }),
  unitPrice: double("unitPrice").default(65).notNull(),
  meterNumber: varchar("meterNumber", { length: 100 }),
  meterType: varchar("meterType", { length: 100 }),
  meterLocation: varchar("meterLocation", { length: 200 }),
  latestMeterPhotoUrl: text("latestMeterPhotoUrl"),
  lifecycleStatus: mysqlEnum("lifecycleStatus", ["active", "closed"]).default("active").notNull(),
  closedAt: timestamp("closedAt"),
  closeReason: varchar("closeReason", { length: 500 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  serialUnique: uniqueIndex("customers_serial_unique").on(table.serialNumber),
  sNoUnique: uniqueIndex("customers_sno_unique").on(table.sNo),
  nameIndex: index("customers_name_idx").on(table.name),
}));

export const monthlyBills = mysqlTable("monthly_bills", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull().references(() => customers.id, { onDelete: "restrict" }),
  customerName: varchar("customerName", { length: 200 }).notNull(),
  invoiceNumber: varchar("invoiceNumber", { length: 40 }).notNull(),
  month: int("month").notNull(),
  year: int("year").notNull(),
  previousReading: double("previousReading").default(0).notNull(),
  currentReading: double("currentReading").default(0).notNull(),
  unitsConsumed: double("unitsConsumed").default(0).notNull(),
  unitPrice: double("unitPrice").default(65).notNull(),
  previousOutstanding: double("previousOutstanding").default(0).notNull(),
  amount: double("amount").default(0).notNull(),
  discount: double("discount").default(0).notNull(),
  lateFee: double("lateFee").default(0).notNull(),
  totalPayable: double("totalPayable").default(0).notNull(),
  receivedAmount: double("receivedAmount").default(0).notNull(),
  outstandingAmount: double("outstandingAmount").default(0).notNull(),
  readingDate: varchar("readingDate", { length: 10 }),
  meterReaderName: varchar("meterReaderName", { length: 200 }),
  meterReadingPhotoUrl: text("meterReadingPhotoUrl"),
  issuedDate: varchar("issuedDate", { length: 10 }).notNull(),
  dueDate: varchar("dueDate", { length: 10 }).notNull(),
  receivedDate: varchar("receivedDate", { length: 10 }),
  paymentMethod: mysqlEnum("paymentMethod", ["Cash", "JazzCash", "Easypaisa", "Bank"]),
  remarks: text("remarks"),
  status: mysqlEnum("status", ["Paid", "Unpaid", "Overdue"]).default("Unpaid").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  customerPeriodUnique: uniqueIndex("bills_customer_period_unique").on(table.customerId, table.year, table.month),
  invoiceUnique: uniqueIndex("bills_invoice_unique").on(table.invoiceNumber),
  periodIndex: index("bills_period_idx").on(table.year, table.month),
  statusIndex: index("bills_status_idx").on(table.status),
}));

export const wapdaRecords = mysqlTable("wapda_records", {
  id: int("id").autoincrement().primaryKey(),
  month: int("month").notNull(),
  year: int("year").notNull(),
  previousReading: double("previousReading").default(0).notNull(),
  currentReading: double("currentReading").default(0).notNull(),
  unitsConsumed: double("unitsConsumed").default(0).notNull(),
  ratePerUnit: double("ratePerUnit").default(65).notNull(),
  totalBill: double("totalBill").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  periodUnique: uniqueIndex("wapda_period_unique").on(table.year, table.month),
  }));

export const dailyWapdaRecords = mysqlTable("daily_wapda_records", {
  id: int("id").autoincrement().primaryKey(),
  month: int("month").notNull(),
  year: int("year").notNull(),
  readingDate: varchar("readingDate", { length: 10 }).notNull(),
  previousReading: double("previousReading").default(0).notNull(),
  currentReading: double("currentReading").default(0).notNull(),
  unitsConsumed: double("unitsConsumed").default(0).notNull(),
  ratePerUnit: double("ratePerUnit").default(65).notNull(),
  totalBill: double("totalBill").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  dateUnique: uniqueIndex("daily_wapda_date_unique").on(table.year, table.month, table.readingDate),
  periodIndex: index("daily_wapda_period_idx").on(table.year, table.month),
  }));

export const customerDailyWapdaRecords = mysqlTable("customer_daily_wapda_records", {
  id: int("id").autoincrement().primaryKey(),
  customerId: int("customerId").notNull().references(() => customers.id, { onDelete: "restrict" }),
  customerName: varchar("customerName", { length: 200 }).notNull(),
  sNo: int("sNo").notNull(),
  month: int("month").notNull(),
  year: int("year").notNull(),
  readingDate: varchar("readingDate", { length: 10 }).notNull(),
  previousReading: double("previousReading").default(0).notNull(),
  currentReading: double("currentReading").default(0).notNull(),
  unitsConsumed: double("unitsConsumed").default(0).notNull(),
  ratePerUnit: double("ratePerUnit").default(65).notNull(),
  totalAmount: double("totalAmount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  customerDateUnique: uniqueIndex("customer_daily_wapda_unique").on(table.customerId, table.year, table.month, table.readingDate),
  periodIndex: index("customer_daily_wapda_period_idx").on(table.year, table.month),
  customerIndex: index("customer_daily_wapda_customer_idx").on(table.customerId),
}));

export const companySettings = mysqlTable("company_settings", {
  id: int("id").primaryKey().default(1),
  companyName: varchar("companyName", { length: 200 }).default("ATOZ SOLAR SYSTEM").notNull(),
  logoUrl: text("logoUrl"),
  address: text("address"),
  phone: varchar("phone", { length: 50 }),
  whatsapp: varchar("whatsapp", { length: 50 }),
  email: varchar("email", { length: 320 }),
  website: varchar("website", { length: 320 }),
  jazzcashQrUrl: text("jazzcashQrUrl"),
  jazzcashAccount: text("jazzcashAccount"),
  easypaisaQrUrl: text("easypaisaQrUrl"),
  easypaisaAccount: text("easypaisaAccount"),
  bankQrUrl: text("bankQrUrl"),
  bankAccountDetails: text("bankAccountDetails"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
export type Customer = typeof customers.$inferSelect;
export type MonthlyBill = typeof monthlyBills.$inferSelect;
export type WapdaRecord = typeof wapdaRecords.$inferSelect;
export type DailyWapdaRecord = typeof dailyWapdaRecords.$inferSelect;
export type CustomerDailyWapdaRecord = typeof customerDailyWapdaRecords.$inferSelect;
export type CompanySettings = typeof companySettings.$inferSelect;
