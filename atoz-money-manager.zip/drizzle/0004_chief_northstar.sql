CREATE TABLE `daily_wapda_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`month` int NOT NULL,
	`year` int NOT NULL,
	`readingDate` varchar(10) NOT NULL,
	`previousReading` double NOT NULL DEFAULT 0,
	`currentReading` double NOT NULL DEFAULT 0,
	`unitsConsumed` double NOT NULL DEFAULT 0,
	`ratePerUnit` double NOT NULL DEFAULT 45,
	`totalBill` double NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `daily_wapda_records_id` PRIMARY KEY(`id`),
	CONSTRAINT `daily_wapda_date_unique` UNIQUE(`year`,`month`,`readingDate`)
);
--> statement-breakpoint
CREATE INDEX `daily_wapda_period_idx` ON `daily_wapda_records` (`year`,`month`);