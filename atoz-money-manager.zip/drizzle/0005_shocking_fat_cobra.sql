ALTER TABLE `customers` MODIFY COLUMN `unitPrice` double NOT NULL DEFAULT 65;--> statement-breakpoint
ALTER TABLE `daily_wapda_records` MODIFY COLUMN `ratePerUnit` double NOT NULL DEFAULT 65;--> statement-breakpoint
ALTER TABLE `monthly_bills` MODIFY COLUMN `unitPrice` double NOT NULL DEFAULT 65;--> statement-breakpoint
ALTER TABLE `wapda_records` MODIFY COLUMN `ratePerUnit` double NOT NULL DEFAULT 65;