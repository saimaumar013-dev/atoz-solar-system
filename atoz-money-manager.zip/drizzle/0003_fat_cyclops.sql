ALTER TABLE `customers` ADD `sNo` int NULL;--> statement-breakpoint
UPDATE `customers` c JOIN (SELECT `id`, ROW_NUMBER() OVER (ORDER BY `serialNumber`, `id`) AS `rn` FROM `customers`) ranked ON ranked.`id` = c.`id` SET c.`sNo` = ranked.`rn`;--> statement-breakpoint
ALTER TABLE `customers` MODIFY `sNo` int NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD CONSTRAINT `customers_sno_unique` UNIQUE(`sNo`);--> statement-breakpoint
