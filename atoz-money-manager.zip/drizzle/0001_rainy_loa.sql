CREATE TABLE `company_settings` (
	`id` int NOT NULL DEFAULT 1,
	`companyName` varchar(200) NOT NULL DEFAULT 'ATOZ SOLAR SYSTEM',
	`logoUrl` text,
	`address` text,
	`phone` varchar(50),
	`whatsapp` varchar(50),
	`email` varchar(320),
	`website` varchar(320),
	`jazzcashQrUrl` text,
	`jazzcashAccount` text,
	`easypaisaQrUrl` text,
	`easypaisaAccount` text,
	`bankQrUrl` text,
	`bankAccountDetails` text,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `company_settings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `customers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(200) NOT NULL,
	`serialNumber` int NOT NULL,
	`photoUrl` text,
	`email` varchar(320),
	`mobileNumber` varchar(40),
	`whatsappNumber` varchar(40),
	`cnic` varchar(40),
	`address` text,
	`connectionDate` varchar(10),
	`installationDate` varchar(10),
	`unitPrice` double NOT NULL DEFAULT 45,
	`meterNumber` varchar(100),
	`meterType` varchar(100),
	`meterLocation` varchar(200),
	`latestMeterPhotoUrl` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `customers_id` PRIMARY KEY(`id`),
	CONSTRAINT `customers_serial_unique` UNIQUE(`serialNumber`)
);
--> statement-breakpoint
CREATE TABLE `monthly_bills` (
	`id` int AUTO_INCREMENT NOT NULL,
	`customerId` int NOT NULL,
	`customerName` varchar(200) NOT NULL,
	`invoiceNumber` varchar(40) NOT NULL,
	`month` int NOT NULL,
	`year` int NOT NULL,
	`previousReading` double NOT NULL DEFAULT 0,
	`currentReading` double NOT NULL DEFAULT 0,
	`unitsConsumed` double NOT NULL DEFAULT 0,
	`unitPrice` double NOT NULL DEFAULT 45,
	`previousOutstanding` double NOT NULL DEFAULT 0,
	`amount` double NOT NULL DEFAULT 0,
	`discount` double NOT NULL DEFAULT 0,
	`lateFee` double NOT NULL DEFAULT 0,
	`totalPayable` double NOT NULL DEFAULT 0,
	`receivedAmount` double NOT NULL DEFAULT 0,
	`outstandingAmount` double NOT NULL DEFAULT 0,
	`readingDate` varchar(10),
	`meterReaderName` varchar(200),
	`meterReadingPhotoUrl` text,
	`issuedDate` varchar(10) NOT NULL,
	`dueDate` varchar(10) NOT NULL,
	`receivedDate` varchar(10),
	`paymentMethod` enum('Cash','JazzCash','Easypaisa','Bank'),
	`remarks` text,
	`status` enum('Paid','Unpaid','Overdue') NOT NULL DEFAULT 'Unpaid',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `monthly_bills_id` PRIMARY KEY(`id`),
	CONSTRAINT `bills_customer_period_unique` UNIQUE(`customerId`,`year`,`month`),
	CONSTRAINT `bills_invoice_unique` UNIQUE(`invoiceNumber`)
);
--> statement-breakpoint
CREATE TABLE `user_permissions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`canViewCustomers` boolean NOT NULL DEFAULT true,
	`canManageCustomers` boolean NOT NULL DEFAULT false,
	`canViewBills` boolean NOT NULL DEFAULT true,
	`canManageBills` boolean NOT NULL DEFAULT false,
	`canViewReports` boolean NOT NULL DEFAULT true,
	`canManageWapda` boolean NOT NULL DEFAULT false,
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `user_permissions_id` PRIMARY KEY(`id`),
	CONSTRAINT `user_permissions_userId_unique` UNIQUE(`userId`)
);
--> statement-breakpoint
CREATE TABLE `wapda_records` (
	`id` int AUTO_INCREMENT NOT NULL,
	`month` int NOT NULL,
	`year` int NOT NULL,
	`previousReading` double NOT NULL DEFAULT 0,
	`currentReading` double NOT NULL DEFAULT 0,
	`unitsConsumed` double NOT NULL DEFAULT 0,
	`ratePerUnit` double NOT NULL DEFAULT 45,
	`totalBill` double NOT NULL DEFAULT 0,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `wapda_records_id` PRIMARY KEY(`id`),
	CONSTRAINT `wapda_period_unique` UNIQUE(`year`,`month`)
);
--> statement-breakpoint
ALTER TABLE `users` ADD `isActive` boolean DEFAULT true NOT NULL;--> statement-breakpoint
ALTER TABLE `monthly_bills` ADD CONSTRAINT `monthly_bills_customerId_customers_id_fk` FOREIGN KEY (`customerId`) REFERENCES `customers`(`id`) ON DELETE restrict ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `user_permissions` ADD CONSTRAINT `user_permissions_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `customers_name_idx` ON `customers` (`name`);--> statement-breakpoint
CREATE INDEX `bills_period_idx` ON `monthly_bills` (`year`,`month`);--> statement-breakpoint
CREATE INDEX `bills_status_idx` ON `monthly_bills` (`status`);