ALTER TABLE `customers` ADD `lifecycleStatus` enum('active','closed') DEFAULT 'active' NOT NULL;--> statement-breakpoint
ALTER TABLE `customers` ADD `closedAt` timestamp;--> statement-breakpoint
ALTER TABLE `customers` ADD `closeReason` varchar(500);